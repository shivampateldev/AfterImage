@echo off
title AFTERIMAGE: THE LAST ECHO
cd /d "%~dp0"

echo ========================================================
echo   AFTERIMAGE: THE LAST ECHO - Windows Desktop Edition
echo   AN SMP ORIGINAL ^| 1%% CHANCE. 99%% FAITH.
echo ========================================================
echo.
echo Launching local standalone game engine...

where node >nul 2>&1
if %ERRORLEVEL% equ 0 (
    node launcher.js
    exit /b
)

:: If node is not in PATH, launch dedicated native browser app mode directly with local file protocol
set "INDEX_PATH=%~dp0app\index.html"
set "USER_DATA=%LOCALAPPDATA%\AfterImageGameData"

if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app="file:///%INDEX_PATH%" --user-data-dir="%USER_DATA%" --window-size=1280,720 --window-position=center --allow-file-access-from-files
    exit /b
)

if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app="file:///%INDEX_PATH%" --user-data-dir="%USER_DATA%" --window-size=1280,720 --window-position=center --allow-file-access-from-files
    exit /b
)

:: Default browser fallback
start "" "%INDEX_PATH%"

