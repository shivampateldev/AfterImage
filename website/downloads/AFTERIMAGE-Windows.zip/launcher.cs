using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace AfterImageLauncher
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string launcherJs = Path.Combine(baseDir, "launcher.js");
            string indexPath = Path.Combine(baseDir, "app", "index.html");
            string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string userDataDir = Path.Combine(localAppData, "AfterImageGameData");

            // 1. Try launching with Node if installed
            try
            {
                ProcessStartInfo psiNode = new ProcessStartInfo
                {
                    FileName = "node.exe",
                    Arguments = "\"" + launcherJs + "\"",
                    WorkingDirectory = baseDir,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                Process p = Process.Start(psiNode);
                if (p != null) return;
            }
            catch { }

            // 2. Fallback directly to Edge/Chrome App Mode
            string[] browsers = new string[]
            {
                @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                @"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
                @"C:\Program Files\Google\Chrome\Application\chrome.exe",
                @"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
            };

            foreach (string b in browsers)
            {
                if (File.Exists(b))
                {
                    try
                    {
                        ProcessStartInfo psiBrowser = new ProcessStartInfo
                        {
                            FileName = b,
                            Arguments = string.Format("--app=\"file:///{0}\" --user-data-dir=\"{1}\" --window-size=1280,720 --window-position=center --allow-file-access-from-files", indexPath.Replace('\\', '/'), userDataDir),
                            UseShellExecute = true
                        };
                        Process.Start(psiBrowser);
                        return;
                    }
                    catch { }
                }
            }

            // 3. Fallback to default browser
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = indexPath,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not launch AFTERIMAGE: " + ex.Message, "AFTERIMAGE: THE LAST ECHO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
