const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn, execSync } = require('child_process');

const APP_DIR = path.join(__dirname, 'app');
const PORT = 47892;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.wasm': 'application/wasm',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
};

// 1. Start local embedded HTTP server
const server = http.createServer((req, res) => {
  let reqPath = decodeURIComponent(req.url.split('?')[0]);
  if (reqPath === '/' || reqPath === '') {
    reqPath = '/index.html';
  }

  let filePath = path.join(APP_DIR, reqPath);

  // Security: prevent directory traversal
  if (!filePath.startsWith(APP_DIR)) {
    res.statusCode = 403;
    res.end('Access Denied');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fallback to index.html for SPA routing
      filePath = path.join(APP_DIR, 'index.html');
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
    });

    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  });
});

server.listen(PORT, '127.0.0.1', () => {
  const gameUrl = `http://127.0.0.1:${PORT}`;
  console.log(`[AFTERIMAGE Launcher] Local Game Server running at ${gameUrl}`);

  // 2. Discover Chrome or Edge on Windows
  const candidates = [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  ];

  let browserPath = null;
  for (const c of candidates) {
    if (fs.existsSync(c)) {
      browserPath = c;
      break;
    }
  }

  const userDataDir = path.join(process.env.LOCALAPPDATA || process.env.TEMP, 'AfterImageGameData');

  if (browserPath) {
    console.log(`[AFTERIMAGE Launcher] Launching via dedicated application window: ${browserPath}`);
    // Native standalone window mode with fixed 16:9 ratio, no browser chrome/tabs, crisp rendering
    const args = [
      `--app=${gameUrl}`,
      `--user-data-dir=${userDataDir}`,
      '--window-size=1280,720',
      '--window-position=center',
      '--force-device-scale-factor=1',
      '--disable-features=TranslateUI',
      '--disable-extensions',
      '--no-first-run',
      '--no-default-browser-check',
      '--autoplay-policy=no-user-gesture-required',
    ];

    const child = spawn(browserPath, args, {
      detached: false,
      stdio: 'ignore',
    });

    child.on('exit', () => {
      console.log('[AFTERIMAGE Launcher] Game closed. Shutting down.');
      server.close();
      process.exit(0);
    });
  } else {
    // Fallback: open default system browser
    console.log('[AFTERIMAGE Launcher] Opening in default browser...');
    const startCmd = process.platform === 'win32' ? `start "" "${gameUrl}"` : `open "${gameUrl}"`;
    execSync(startCmd);
  }
});

process.on('SIGINT', () => {
  server.close();
  process.exit(0);
});
